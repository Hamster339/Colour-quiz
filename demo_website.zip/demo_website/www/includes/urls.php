<?php
//Urls for links on pages
$index = "http://localhost/demoSite/";
$submited = "http://localhost/demoSite/submited.php";
$results = "http://localhost/demoSite/results.php";
$EditOrRemove = "http://localhost/demoSite/EditOrRemove.php";

?>
