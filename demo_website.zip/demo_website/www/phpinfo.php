<?php
//page shows info about installed vertion of php
phpinfo();
?>
